import 'package:get/state_manager.dart';

class SignupController extends GetxController {}
