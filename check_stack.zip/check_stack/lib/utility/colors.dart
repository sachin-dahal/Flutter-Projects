import 'package:flutter/widgets.dart';

const Color kPrimaryColor = Color(0xFFEF652D);
const Color kSecondaryColor = Color(0xFFF4F4F4);
const Color kTeritaryColor = Color(0xFFB2B2B2);

const Color kBgColor1 = Color(0xFFFFFFFF);
const Color kBgColor2 = Color(0xFFF4F4F4);

const Color kTextColor1 = Color(0xFF292929);
const Color kTextColor2 = Color(0xFF979797);
