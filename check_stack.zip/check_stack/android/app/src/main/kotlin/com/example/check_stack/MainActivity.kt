package com.example.check_stack

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
